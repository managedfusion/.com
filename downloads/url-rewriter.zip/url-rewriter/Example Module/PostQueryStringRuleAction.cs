﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Web;

using ManagedFusion.Rewriter;
using MySql.Data.MySqlClient;

namespace CoderJournal.Rewriter.Rules
{
	/// <summary>
	/// 
	/// </summary>
	public class PostQueryStringRuleAction : IRuleAction
	{
		#region IRuleAction Members

		/// <summary>
		/// Gets the text.
		/// </summary>
		/// <value>The text.</value>
		public string Text
		{
			get;
			private set;
		}

		/// <summary>
		/// Processes the specified log level.
		/// </summary>
		/// <param name="logLevel">The log level.</param>
		/// <param name="context">The context.</param>
		/// <param name="pattern">The pattern.</param>
		/// <param name="url">The URL.</param>
		/// <param name="flags">The flags.</param>
		/// <returns></returns>
		public Uri Execute(int logLevel, HttpContext context, Pattern pattern, Uri url, IDictionary<string, string> flags)
		{
			string inputUrl = url.GetComponents(UriComponents.PathAndQuery, UriFormat.UriEscaped);
			string sqlCommand = pattern.Replace(inputUrl, Text);
			string returnedUrl = String.Empty;

			using (MySqlConnection connection = new MySqlConnection(Properties.Settings.Default.DatabaseConnection))
			{
				using (MySqlCommand command = connection.CreateCommand())
				{
					command.CommandText = sqlCommand;
					command.CommandType = CommandType.Text;

					try
					{
						connection.Open();
						returnedUrl = command.ExecuteScalar() as string;
					}
					finally
					{
						connection.Close();
					}
				}
			}

			return new Uri(url, returnedUrl);
		}

		/// <summary>
		/// Inits the specified text.
		/// </summary>
		/// <param name="text">The text.</param>
		public void Init(string text)
		{
			Text = text;
		}

		#endregion
	}
}
